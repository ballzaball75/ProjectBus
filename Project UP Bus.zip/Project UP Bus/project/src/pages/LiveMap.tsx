import React, { useState } from 'react';
import RouteSelector from '../components/RouteSelector';
import { RouteType } from '../types';
import image1 from 'Z:/1/project/pic/1.png';
import image2 from 'Z:/1/project/pic/2.png';
import image3 from 'Z:/1/project/pic/3.png';


const LiveMap: React.FC = () => {
  const [selectedRoute, setSelectedRoute] = useState<RouteType>('วิศวะ');

  const getMapImageUrl = () => {
    switch (selectedRoute) {
      case 'วิศวะ':
        return image1;
      case 'ICT':
        return image2;
      case 'หอพัก':
        return image3;
      default:
        return '';
    }
  };
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-center">Live Map</h1>
      <div className="mb-6">
        <RouteSelector selectedRoute={selectedRoute} onRouteChange={setSelectedRoute} />
      </div>
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <img 
          src={getMapImageUrl()} 
          alt={`${selectedRoute} route map`} 
          className="w-full h-auto"
        />
      </div>
      <div className="mt-4 bg-gray-100 p-4 rounded-lg">
        <p className="text-center text-gray-700">
          แสดงตำแหน่งรถบัสแบบเรียลไทม์สำหรับเส้นทาง {selectedRoute}
        </p>
      </div>
    </div>
  );
};

export default LiveMap;