import React, { useState } from 'react';
import { Bell, BellOff } from 'lucide-react';
import { busStops } from '../data/busStops';

const BusNearMe: React.FC = () => {
  const [selectedStop, setSelectedStop] = useState<number | null>(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  const handleStopSelect = (stopId: number) => {
    setSelectedStop(stopId);
    setNotificationsEnabled(false);
  };

  const toggleNotifications = () => {
    if (selectedStop === null) {
      alert('กรุณาเลือกป้ายจอดก่อน');
      return;
    }
    setNotificationsEnabled(!notificationsEnabled);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-center">Bus Near Me</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">เลือกป้ายจอด</h2>
        <div className="mb-6">
          <select
            className="w-full p-2 border border-gray-300 rounded-md"
            value={selectedStop || ''}
            onChange={(e) => handleStopSelect(Number(e.target.value))}
          >
            <option value="">-- เลือกป้ายจอด --</option>
            {busStops.map(stop => (
              <option key={stop.id} value={stop.id}>
                {stop.name}
              </option>
            ))}
          </select>
        </div>
        
        <div className="flex flex-col items-center justify-center p-6 bg-gray-50 rounded-lg">
          <div className="mb-4 text-center">
            {selectedStop ? (
              <p className="font-medium">
                ป้ายที่เลือก: {busStops.find(stop => stop.id === selectedStop)?.name}
              </p>
            ) : (
              <p className="text-gray-500">กรุณาเลือกป้ายจอด</p>
            )}
          </div>
          
          <button
            onClick={toggleNotifications}
            disabled={selectedStop === null}
            className={`flex items-center space-x-2 px-6 py-3 rounded-full ${
              notificationsEnabled 
                ? 'bg-red-500 hover:bg-red-600 text-white' 
                : 'bg-green-500 hover:bg-green-600 text-white'
            } ${selectedStop === null ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {notificationsEnabled ? (
              <>
                <BellOff size={20} />
                <span>ปิดการแจ้งเตือน</span>
              </>
            ) : (
              <>
                <Bell size={20} />
                <span>เปิดการแจ้งเตือน</span>
              </>
            )}
          </button>
          
          {notificationsEnabled && (
            <div className="mt-6 p-4 bg-blue-50 text-blue-700 rounded-lg text-center">
              <p>ระบบจะแจ้งเตือนเมื่อมีรถบัสเข้าใกล้ป้ายที่คุณเลือก</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BusNearMe;