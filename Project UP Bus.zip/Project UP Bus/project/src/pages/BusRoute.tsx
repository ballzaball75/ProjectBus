import React, { useState } from 'react';
import RouteSelector from '../components/RouteSelector';
import { RouteType } from '../types';

import image1 from 'Z:/1/project/pic/widwa.png';
import image2 from 'Z:/1/project/pic/hor.png';
import image3 from 'Z:/1/project/pic/ICT_.png';


const BusRoute: React.FC = () => {
  const [selectedRoute, setSelectedRoute] = useState<RouteType>('วิศวะ');

  const getRouteImageUrl = () => {
    switch (selectedRoute) {
      case 'วิศวะ':
        return image1;
      case 'ICT':
        return image3;
      case 'หอพัก':
        return image2;
      default:
        return '';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-center">Bus Route</h1>
      <div className="mb-6">
        <RouteSelector selectedRoute={selectedRoute} onRouteChange={setSelectedRoute} />
      </div>
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <img 
          src={getRouteImageUrl()} 
          alt={`${selectedRoute} route map`} 
          className="w-full h-auto"
        />
      </div>
    </div>
  );
};

export default BusRoute;