export interface BusStop {
  id: number;
  name: string;
}

export type RouteType = 'วิศวะ' | 'ICT' | 'หอพัก';