import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import LiveMap from './pages/LiveMap';
import BusRoute from './pages/BusRoute';
import BusStop from './pages/BusStop';
import BusNearMe from './pages/BusNearMe';
import Feedback from './pages/Feedback';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Navbar />
        <main className="container mx-auto py-6 px-4">
          <Routes>
            <Route path="/" element={<LiveMap />} />
            <Route path="/bus-route" element={<BusRoute />} />
            <Route path="/bus-stop" element={<BusStop />} />
            <Route path="/bus-near-me" element={<BusNearMe />} />
            <Route path="/feedback" element={<Feedback />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;