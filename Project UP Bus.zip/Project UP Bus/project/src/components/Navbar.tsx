import React from 'react';
import { NavLink } from 'react-router-dom';
import { Bus, Map, MapPin, Bell, MessageSquare } from 'lucide-react';

const Navbar: React.FC = () => {
  return (
    <nav className="bg-blue-600 text-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <Bus size={24} />
            <span className="text-xl font-bold">UP Bus</span>
          </div>
          <div className="flex space-x-6">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                isActive ? "flex items-center space-x-1 border-b-2 border-white" : "flex items-center space-x-1 hover:border-b-2 hover:border-white"
              }
            >
              <Map size={18} />
              <span>Live Map</span>
            </NavLink>
            <NavLink 
              to="/bus-route" 
              className={({ isActive }) => 
                isActive ? "flex items-center space-x-1 border-b-2 border-white" : "flex items-center space-x-1 hover:border-b-2 hover:border-white"
              }
            >
              <Bus size={18} />
              <span>Bus Route</span>
            </NavLink>
            <NavLink 
              to="/bus-stop" 
              className={({ isActive }) => 
                isActive ? "flex items-center space-x-1 border-b-2 border-white" : "flex items-center space-x-1 hover:border-b-2 hover:border-white"
              }
            >
              <MapPin size={18} />
              <span>Bus Stop</span>
            </NavLink>
            <NavLink 
              to="/bus-near-me" 
              className={({ isActive }) => 
                isActive ? "flex items-center space-x-1 border-b-2 border-white" : "flex items-center space-x-1 hover:border-b-2 hover:border-white"
              }
            >
              <Bell size={18} />
              <span>Bus Near Me</span>
            </NavLink>
            <NavLink 
              to="/feedback" 
              className={({ isActive }) => 
                isActive ? "flex items-center space-x-1 border-b-2 border-white" : "flex items-center space-x-1 hover:border-b-2 hover:border-white"
              }
            >
              <MessageSquare size={18} />
              <span>Feedback</span>
            </NavLink>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;