import React from 'react';
import { RouteType } from '../types';

interface RouteSelectorProps {
  selectedRoute: RouteType;
  onRouteChange: (route: RouteType) => void;
}

const RouteSelector: React.FC<RouteSelectorProps> = ({ selectedRoute, onRouteChange }) => {
  return (
    <div className="flex w-full border rounded-lg overflow-hidden shadow-sm">
      <button
        className={`flex-1 py-3 transition-colors duration-200 ${selectedRoute === 'วิศวะ' ? 'bg-green-500 text-white' : 'bg-white text-green-500 hover:bg-green-50'}`}
        onClick={() => onRouteChange('วิศวะ')}
      >
        <div className="text-xl font-bold">1</div>
        <div>สายวิศวะ</div>
      </button>
      <button
        className={`flex-1 py-3 transition-colors duration-200 ${selectedRoute === 'ICT' ? 'bg-blue-600 text-white' : 'bg-white text-blue-600 hover:bg-blue-50'}`}
        onClick={() => onRouteChange('ICT')}
      >
        <div className="text-xl font-bold">2</div>
        <div>สาย ICT</div>
      </button>
      <button
        className={`flex-1 py-3 transition-colors duration-200 ${selectedRoute === 'หอพัก' ? 'bg-red-500 text-white' : 'bg-white text-red-500 hover:bg-red-50'}`}
        onClick={() => onRouteChange('หอพัก')}
      >
        <div className="text-xl font-bold">3</div>
        <div>สายหอพัก</div>
      </button>
    </div>
  );
};

export default RouteSelector;